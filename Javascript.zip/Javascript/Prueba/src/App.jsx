import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import AppRoutes from '../src/routes/Routes';
import './App.css'; // Asegúrate de que el CSS esté importado si lo estás usando

const App = () => {
    return (
        <Router>
            <div className="app-container">
                <AppRoutes />
            </div>
        </Router>
    );
};

export default App;