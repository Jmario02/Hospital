import React from 'react';
import { Route, Routes } from 'react-router-dom';
// rutas de la app

import  Home from './home/home.jsx';
import Register from './register/Register.jsx';
import Login from './login/Login.jsx';
import NotFound from './NotFound/NotFound.jsx'; 
import HomeApp from './homeApp/homeApp.jsx';
import PrivateRoute from './PrivateRoutes/PrivateRoute.jsx';
import About from './about/About.jsx';


const AppRoutes = () => {
    return (
        <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/homeApp" element={<PrivateRoute element={HomeApp} />} /> 
        <Route path="*" element={<NotFound />} /> 
        <Route path="/about" element={<About />} />
    </Routes>
    );
};

export default AppRoutes;