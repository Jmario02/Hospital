import React from 'react';
import { useNavigate } from 'react-router-dom';

function Home() {
  const navigate = useNavigate();

  const handleLoginClick = () => {
    navigate('/login');  // Navega a la ruta de "Iniciar Sesión"
  };

  const handleRegisterClick = () => {
    navigate('/register');  // Navega a la ruta de "Registrarse"
  };

  const handleAboutClick = () => {
    navigate('/about');  // Navega a la ruta de "Registrarse"
  };

  return (
    <div>
      {/* Encabezado */}
      <header className="header">
        <div className="logo">
          <h1>Hospital General</h1>
        </div>
        <nav className="nav">
          <ul>
            <li><a href="#">Inicio</a></li>
            <li><a href="#">Noticias Médicas</a></li>
            <li><a href="#">Salud Pública</a></li>
            <li><a href="#">Eventos</a></li>
            <li><a href="#" onClick={handleLoginClick}>Citas Médicas</a></li>
            <li><a href="#" onClick={handleAboutClick}>Contacto</a></li>
          </ul>
        </nav>
        <div className="search-bar">
          <input type="text" placeholder="Buscar..." />
        </div>
      </header>


    </div>
  );
}

export default Home;