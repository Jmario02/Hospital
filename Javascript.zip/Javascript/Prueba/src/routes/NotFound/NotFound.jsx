import React from 'react';
import '../NotFound/NotFound-styles.css'

const NotFound = () => {
    return (
        <div className="not-found">
            <h1>404</h1>
            <p>La página que buscas no existe.</p>
        </div>
    );
};

export default NotFound;
