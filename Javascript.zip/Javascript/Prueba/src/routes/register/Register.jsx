import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';


const Register = () => {

    const navigate = useNavigate();

    const handleHomeClick = () => {
        navigate('/');  // Navega a la ruta de "Iniciar Sesión"
    };
    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [userType, setUserType] = useState("user"); // Estado para el tipo de usuario
    const [error, setError] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        
        // Validaciones simples
        if (!email || !password || !username || !confirmPassword) {
            setError('Todos los campos son requeridos');
            return;
        }

        if (password !== confirmPassword) {
            setError('Las contraseñas no coinciden');
            return;
        }
        
        // Aquí iría la lógica para autenticar al usuario, por ejemplo:
        // Enviar los datos a una API de autenticación
        console.log('Email:', email);
        console.log('Password:', password);
        console.log('Username:', username);
        console.log('User Type:', userType);
        
        alert('El usuario fue creado con exito')
        navigate('/login');  // Navega a la ruta de "Iniciar Sesión"
        // Limpiar el error y los campos si la autenticación es exitosa
        setError('');
        setEmail('');
        setPassword('');
        setConfirmPassword('');
        setUsername('');
        setUserType('user'); // Restablecer tipo de usuario a valor predeterminado
    };

    return (
        <div className="register-container">
            <h1>Registro de usuario</h1>

            {error && <p className="error">{error}</p>}
            
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="username">Nombre de usuario:</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="email">Ingrese su correo electrónico:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="password">Ingrese su contraseña:</label>
                    <input
                        type="password"
                        id="password"
                        name="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="confirmPassword">Repita la contraseña:</label>
                    <input
                        type="password"
                        id="confirmPassword"
                        name="confirmPassword"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label>Tipo de usuario:</label>
                    <div>
                        <label>
                            <input
                                type="radio"
                                value="admin"
                                checked={userType === "admin"}
                                onChange={(e) => setUserType(e.target.value)}
                            />
                            Administrador
                        </label>
                        <label>
                            <input
                                type="radio"
                                value="user"
                                checked={userType === "user"}
                                onChange={(e) => setUserType(e.target.value)}
                            />
                            Usuario
                        </label>
                    </div>
                </div>

                <button type="submit" className="register-button">Guardar INFO</button>
            </form>
            <button onClick={handleHomeClick}>Atras</button>
        </div>
    );
};

export default Register;

