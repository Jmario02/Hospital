import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../homeApp/homeApp-styles.css'

const HomeApp = () => {
    const navigate = useNavigate();

    const handleLogout = () => {
        localStorage.removeItem('authToken'); // Elimina el token de autenticación
        navigate('/'); // Redirige al usuario 
        
    };

    return (
        <div>
      
    </div>
    );
};

export default HomeApp;