import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../login/Login-styles.css';

const Login = () => {
  const navigate = useNavigate();

  // Estado para manejar los valores del formulario y los errores
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validaciones simples
    if (!email || !password) {
      setError('Todos los campos son requeridos');
      return;
    }

    // Verifica las credenciales
    if (email === 'julio.mario.4523@gmail.com' && password === '0') {
      // Guardar token de autenticación en localStorage
      localStorage.setItem('authToken', 'mi-token-de-autenticacion');
      navigate('/homeApp');
    } else {
      setError('Email o contraseña incorrectos');
    }

    // Limpiar los campos si la autenticación es exitosa
    setEmail('');
    setPassword('');
  };

  const handleHomeClick = () => {
    navigate('/');  // Navega a la página de inicio
  };

  const handleRegisterClick = () => {
    navigate('/register');  // Navega a la página de registro
  };

  return (
    <div className="login-container">
      <h1>Iniciar Sesión</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Contraseña:</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && <p className="error">{error}</p>}
        <button type="submit" className="login-button">Iniciar Sesión</button>
      </form>
      <button onClick={handleRegisterClick}>Registarse</button>
      <button onClick={handleHomeClick}>Atras</button>
    </div>
  );
};

export default Login;
